<!-- 主体内容 -->
<template>
<div class="main-content">
<div class="breadcrumbs" id="breadcrumbs">
<ul class="breadcrumb">
<li>
	<i class="icon-home home-icon"></i>
	<a href="#">首页</a>
</li>
<li class="active">控制台</li>
</ul><!-- .breadcrumb -->

<div class="nav-search" id="nav-search">
<form class="form-search">
	<span class="input-icon">
		<input class="nav-search-input" id="nav-search-input" type="text" placeholder="Search ..." autocomplete="off">
		<i class="icon-search nav-search-icon"></i>
	</span>
</form>
</div><!-- #nav-search -->
</div>

<div class="page-content">
<div class="page-header">
<h1>
	控制台
	<small>
		<i class="icon-double-angle-right"></i>
		 查看
	</small>
</h1>
</div><!-- /.page-header -->

<div class="row">
<div class="col-xs-12">
	<!-- PAGE CONTENT BEGINS -->

	<div class="alert alert-block alert-success">
		<button class="close" type="button" data-dismiss="alert">
			<i class="icon-remove"></i>
		</button>

		<i class="icon-ok green"></i>

		欢迎使用
		<strong class="green">
			Ace后台管理系统
			<small>(v1.2)</small>
		</strong>
		,轻量级好用的后台管理系统模版.	
	</div>

	<div class="row">
		<div class="space-6"></div>

		<div class="col-sm-7 infobox-container">
			<div class="infobox infobox-green  ">
				<div class="infobox-icon">
					<i class="icon-comments"></i>
				</div>

				<div class="infobox-data">
					<span class="infobox-data-number">32</span>
					<div class="infobox-content">2个评论</div>
				</div>
				<div class="stat stat-success">8%</div>
			</div>

			<div class="infobox infobox-blue  ">
				<div class="infobox-icon">
					<i class="icon-twitter"></i>
				</div>

				<div class="infobox-data">
					<span class="infobox-data-number">11</span>
					<div class="infobox-content">新粉丝</div>
				</div>

				<div class="badge badge-success">
					+32%
					<i class="icon-arrow-up"></i>
				</div>
			</div>

			<div class="infobox infobox-pink  ">
				<div class="infobox-icon">
					<i class="icon-shopping-cart"></i>
				</div>

				<div class="infobox-data">
					<span class="infobox-data-number">8</span>
					<div class="infobox-content">新订单</div>
				</div>
				<div class="stat stat-important">4%</div>
			</div>

			<div class="infobox infobox-red  ">
				<div class="infobox-icon">
					<i class="icon-beaker"></i>
				</div>

				<div class="infobox-data">
					<span class="infobox-data-number">7</span>
					<div class="infobox-content">调查</div>
				</div>
			</div>

			<div class="infobox infobox-orange2  ">
				<div class="infobox-chart">
					<span class="sparkline" data-values="196,128,202,177,154,94,100,170,224"></span>
				</div>

				<div class="infobox-data">
					<span class="infobox-data-number">6,251</span>
					<div class="infobox-content">页面查看次数</div>
				</div>

				<div class="badge badge-success">
					7.2%
					<i class="icon-arrow-up"></i>
				</div>
			</div>

			<div class="infobox infobox-blue2  ">
				<div class="infobox-progress">
					<div class="easy-pie-chart percentage" data-percent="42" data-size="46">
						<span class="percent">42</span>%
					</div>
				</div>

				<div class="infobox-data">
					<span class="infobox-text">交易使用</span>

					<div class="infobox-content">
						<span class="bigger-110">~</span>
						剩余58GB
					</div>
				</div>
			</div>

			<div class="space-6"></div>

			<div class="infobox infobox-green infobox-small infobox-dark">
				<div class="infobox-progress">
					<div class="easy-pie-chart percentage" data-percent="61" data-size="39">
						<span class="percent">61</span>%
					</div>
				</div>

				<div class="infobox-data">
					<div class="infobox-content">任务</div>
					<div class="infobox-content">完成</div>
				</div>
			</div>

			<div class="infobox infobox-blue infobox-small infobox-dark">
				<div class="infobox-chart">
					<span class="sparkline" data-values="3,4,2,3,4,4,2,2"></span>
				</div>

				<div class="infobox-data">
					<div class="infobox-content">获得</div>
					<div class="infobox-content">$32,000</div>
				</div>
			</div>

			<div class="infobox infobox-grey infobox-small infobox-dark">
				<div class="infobox-icon">
					<i class="icon-download-alt"></i>
				</div>

				<div class="infobox-data">
					<div class="infobox-content">下载次数</div>
					<div class="infobox-content">1,205</div>
				</div>
			</div>
		</div>

		<div class="vspace-sm"></div>

		<div class="col-sm-5">
			<div class="widget-box">
				<div class="widget-header widget-header-flat widget-header-small">
					<h5>
						<i class="icon-signal"></i>
						访问来源
					</h5>

					<div class="widget-toolbar no-border">
						<button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown">
							本周
							<i class="icon-angle-down icon-on-right bigger-110"></i>
						</button>

						<ul class="dropdown-menu pull-right dropdown-125 dropdown-lighter dropdown-caret">
							<li class="active">
								<a class="blue" href="#">
									<i class="icon-caret-right bigger-110">&nbsp;</i>
									本周
								</a>
							</li>

							<li>
								<a href="#">
									<i class="icon-caret-right bigger-110 invisible">&nbsp;</i>
									上周
								</a>
							</li>

							<li>
								<a href="#">
									<i class="icon-caret-right bigger-110 invisible">&nbsp;</i>
									本月
								</a>
							</li>

							<li>
								<a href="#">
									<i class="icon-caret-right bigger-110 invisible">&nbsp;</i>
									上月
								</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="widget-body">
					<div class="widget-main">
						<div id="piechart-placeholder"></div>

						<div class="hr hr8 hr-double"></div>

						<div class="clearfix">
							<div class="grid3">
								<span class="grey">
									<i class="icon-facebook-sign icon-2x blue"></i>
									&nbsp; likes
								</span>
								<h4 class="bigger pull-right">1,255</h4>
							</div>

							<div class="grid3">
								<span class="grey">
									<i class="icon-twitter-sign icon-2x purple"></i>
									&nbsp; tweets
								</span>
								<h4 class="bigger pull-right">941</h4>
							</div>

							<div class="grid3">
								<span class="grey">
									<i class="icon-pinterest-sign icon-2x red"></i>
									&nbsp; pins
								</span>
								<h4 class="bigger pull-right">1,050</h4>
							</div>
						</div>
					</div><!-- /widget-main -->
				</div><!-- /widget-body -->
			</div><!-- /widget-box -->
		</div><!-- /span -->
	</div><!-- /row -->

	<div class="hr hr32 hr-dotted"></div>

	<div class="row">
		<div class="col-sm-5">
			<div class="widget-box transparent">
				<div class="widget-header widget-header-flat">
					<h4 class="lighter">
						<i class="icon-star orange"></i>
						热门域名
					</h4>

					<div class="widget-toolbar">
						<a href="#" data-action="collapse">
							<i class="icon-chevron-up"></i>
						</a>
					</div>
				</div>

				<div class="widget-body">
					<div class="widget-main no-padding">
						<table class="table table-bordered table-striped">
							<thead class="thin-border-bottom">
								<tr>
									<th>
										<i class="icon-caret-right blue"></i>
										名称
									</th>

									<th>
										<i class="icon-caret-right blue"></i>
										价格
									</th>

									<th class="hidden-480">
										<i class="icon-caret-right blue"></i>
										状态
									</th>
								</tr>
							</thead>

							<tbody>
								<tr>
									<td>internet.com</td>

									<td>
										<small>
											<s class="red">$29.99</s>
										</small>
										<b class="green">$19.99</b>
									</td>

									<td class="hidden-480">
										<span class="label label-info arrowed-right arrowed-in">销售中</span>
									</td>
								</tr>

								<tr>
									<td>online.com</td>

									<td>
										<small>
											<s class="red"></s>
										</small>
										<b class="green">$16.45</b>
									</td>

									<td class="hidden-480">
										<span class="label label-success arrowed-in arrowed-in-right">可用</span>
									</td>
								</tr>

								<tr>
									<td>newnet.com</td>

									<td>
										<small>
											<s class="red"></s>
										</small>
										<b class="green">$15.00</b>
									</td>

									<td class="hidden-480">
										<span class="label label-danger arrowed">待定</span>
									</td>
								</tr>

								<tr>
									<td>web.com</td>

									<td>
										<small>
											<s class="red">$24.99</s>
										</small>
										<b class="green">$19.95</b>
									</td>

									<td class="hidden-480">
										<span class="label arrowed">
											<s>无货</s>
										</span>
									</td>
								</tr>

								<tr>
									<td>domain.com</td>

									<td>
										<small>
											<s class="red"></s>
										</small>
										<b class="green">$12.00</b>
									</td>

									<td class="hidden-480">
										<span class="label label-warning arrowed arrowed-right">售完</span>
									</td>
								</tr>
							</tbody>
						</table>
					</div><!-- /widget-main -->
				</div><!-- /widget-body -->
			</div><!-- /widget-box -->
		</div>

		<div class="col-sm-7">
			<div class="widget-box transparent">
				<div class="widget-header widget-header-flat">
					<h4 class="lighter">
						<i class="icon-signal"></i>
						销售统计
					</h4>

					<div class="widget-toolbar">
						<a href="#" data-action="collapse">
							<i class="icon-chevron-up"></i>
						</a>
					</div>
				</div>

				<div class="widget-body">
					<div class="widget-main padding-4">
						<div id="sales-charts"></div>
					</div><!-- /widget-main -->
				</div><!-- /widget-body -->
			</div><!-- /widget-box -->
		</div>
	</div>

	<div class="hr hr32 hr-dotted"></div>

	<div class="row">
		<div class="col-sm-6">
			<div class="widget-box transparent" id="recent-box">
				<div class="widget-header">
					<h4 class="lighter smaller">
						<i class="icon-rss orange"></i>
						最近
					</h4>

					<div class="widget-toolbar no-border">
						<ul class="nav nav-tabs" id="recent-tab">
							<li class="active">
								<a href="#task-tab" data-toggle="tab">任务</a>
							</li>

							<li>
								<a href="#member-tab" data-toggle="tab">会员</a>
							</li>

							<li>
								<a href="#comment-tab" data-toggle="tab">评论</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="widget-body">
					<div class="widget-main padding-4">
						<div class="tab-content padding-8 overflow-visible">
							<div class="tab-pane active" id="task-tab">
								<h4 class="smaller lighter green">
									<i class="icon-list"></i>
									可拖拽排序列表
								</h4>

								<ul class="item-list" id="tasks">
									<li class="item-orange clearfix">
										<label class="inline">
											<input class="ace" type="checkbox">
											<span class="lbl"> 问答</span>
										</label>

										<div class="pull-right easy-pie-chart percentage" data-percent="42" data-size="30" data-color="#ECCB71">
											<span class="percent">42</span>%
										</div>
									</li>

									<li class="item-red clearfix">
										<label class="inline">
											<input class="ace" type="checkbox">
											<span class="lbl"> BUG修复</span>
										</label>

										<div class="pull-right action-buttons">
											<a class="blue" href="#">
												<i class="icon-pencil bigger-130"></i>
											</a>

											<span class="vbar"></span>

											<a class="red" href="#">
												<i class="icon-trash bigger-130"></i>
											</a>

											<span class="vbar"></span>

											<a class="green" href="#">
												<i class="icon-flag bigger-130"></i>
											</a>
										</div>
									</li>

									<li class="item-default clearfix">
										<label class="inline">
											<input class="ace" type="checkbox">
											<span class="lbl">添加新的特征</span>
										</label>

										<div class="inline pull-right position-relative dropdown-hover">
											<button class="btn btn-minier bigger btn-primary">
												<i class="icon-cog icon-only bigger-120"></i>
											</button>

											<ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-caret dropdown-close pull-right">
												<li>
													<a title="Mark&nbsp;as&nbsp;done" class="tooltip-success" href="#" data-rel="tooltip">
														<span class="green">
															<i class="icon-ok bigger-110"></i>
														</span>
													</a>
												</li>

												<li>
													<a title="Delete" class="tooltip-error" href="#" data-rel="tooltip">
														<span class="red">
															<i class="icon-trash bigger-110"></i>
														</span>
													</a>
												</li>
											</ul>
										</div>
									</li>

									<li class="item-blue clearfix">
										<label class="inline">
											<input class="ace" type="checkbox">
											<span class="lbl"> 更新模版脚本</span>
										</label>
									</li>

									<li class="item-grey clearfix">
										<label class="inline">
											<input class="ace" type="checkbox">
											<span class="lbl"> 添加新皮肤</span>
										</label>
									</li>

									<li class="item-green clearfix">
										<label class="inline">
											<input class="ace" type="checkbox">
											<span class="lbl"> 升级服务端</span>
										</label>
									</li>

									<li class="item-pink clearfix">
										<label class="inline">
											<input class="ace" type="checkbox">
											<span class="lbl"> 清理垃圾</span>
										</label>
									</li>
								</ul>
							</div>

							<div class="tab-pane" id="member-tab">
								<div class="clearfix">
									<div class="itemdiv memberdiv">
										<div class="user">
											<img alt="Bob Doe's avatar" src="static/avatars/user.jpg">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Bob Doe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">20 min</span>
											</div>

											<div>
												<span class="label label-warning label-sm">pending</span>

												<div class="inline position-relative">
													<button class="btn btn-minier bigger btn-yellow btn-no-border dropdown-toggle" data-toggle="dropdown">
														<i class="icon-angle-down icon-only bigger-120"></i>
													</button>

													<ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">
														<li>
															<a title="Approve" class="tooltip-success" href="#" data-rel="tooltip">
																<span class="green">
																	<i class="icon-ok bigger-110"></i>
																</span>
															</a>
														</li>

														<li>
															<a title="Reject" class="tooltip-warning" href="#" data-rel="tooltip">
																<span class="orange">
																	<i class="icon-remove bigger-110"></i>
																</span>
															</a>
														</li>

														<li>
															<a title="Delete" class="tooltip-error" href="#" data-rel="tooltip">
																<span class="red">
																	<i class="icon-trash bigger-110"></i>
																</span>
															</a>
														</li>
													</ul>
												</div>
											</div>
										</div>
									</div>

									<div class="itemdiv memberdiv">
										<div class="user">
											<img alt="Joe Doe's avatar" src="static/avatars/avatar2.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Joe Doe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">1 hour</span>
											</div>

											<div>
												<span class="label label-warning label-sm">pending</span>

												<div class="inline position-relative">
													<button class="btn btn-minier bigger btn-yellow btn-no-border dropdown-toggle" data-toggle="dropdown">
														<i class="icon-angle-down icon-only bigger-120"></i>
													</button>

													<ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">
														<li>
															<a title="Approve" class="tooltip-success" href="#" data-rel="tooltip">
																<span class="green">
																	<i class="icon-ok bigger-110"></i>
																</span>
															</a>
														</li>

														<li>
															<a title="Reject" class="tooltip-warning" href="#" data-rel="tooltip">
																<span class="orange">
																	<i class="icon-remove bigger-110"></i>
																</span>
															</a>
														</li>

														<li>
															<a title="Delete" class="tooltip-error" href="#" data-rel="tooltip">
																<span class="red">
																	<i class="icon-trash bigger-110"></i>
																</span>
															</a>
														</li>
													</ul>
												</div>
											</div>
										</div>
									</div>

									<div class="itemdiv memberdiv">
										<div class="user">
											<img alt="Jim Doe's avatar" src="static/avatars/avatar.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Jim Doe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">2 hour</span>
											</div>

											<div>
												<span class="label label-warning label-sm">pending</span>

												<div class="inline position-relative">
													<button class="btn btn-minier bigger btn-yellow btn-no-border dropdown-toggle" data-toggle="dropdown">
														<i class="icon-angle-down icon-only bigger-120"></i>
													</button>

													<ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">
														<li>
															<a title="Approve" class="tooltip-success" href="#" data-rel="tooltip">
																<span class="green">
																	<i class="icon-ok bigger-110"></i>
																</span>
															</a>
														</li>

														<li>
															<a title="Reject" class="tooltip-warning" href="#" data-rel="tooltip">
																<span class="orange">
																	<i class="icon-remove bigger-110"></i>
																</span>
															</a>
														</li>

														<li>
															<a title="Delete" class="tooltip-error" href="#" data-rel="tooltip">
																<span class="red">
																	<i class="icon-trash bigger-110"></i>
																</span>
															</a>
														</li>
													</ul>
												</div>
											</div>
										</div>
									</div>

									<div class="itemdiv memberdiv">
										<div class="user">
											<img alt="Alex Doe's avatar" src="static/avatars/avatar5.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Alex Doe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">3 hour</span>
											</div>

											<div>
												<span class="label label-danger label-sm">blocked</span>
											</div>
										</div>
									</div>

									<div class="itemdiv memberdiv">
										<div class="user">
											<img alt="Bob Doe's avatar" src="static/avatars/avatar2.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Bob Doe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">6 hour</span>
											</div>

											<div>
												<span class="label label-success label-sm arrowed-in">approved</span>
											</div>
										</div>
									</div>

									<div class="itemdiv memberdiv">
										<div class="user">
											<img alt="Susan's avatar" src="static/avatars/avatar3.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Susan</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">yesterday</span>
											</div>

											<div>
												<span class="label label-success label-sm arrowed-in">approved</span>
											</div>
										</div>
									</div>

									<div class="itemdiv memberdiv">
										<div class="user">
											<img alt="Phil Doe's avatar" src="static/avatars/avatar4.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Phil Doe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">2 days ago</span>
											</div>

											<div>
												<span class="label label-info label-sm arrowed-in arrowed-in-right">online</span>
											</div>
										</div>
									</div>

									<div class="itemdiv memberdiv">
										<div class="user">
											<img alt="Alexa Doe's avatar" src="static/avatars/avatar1.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Alexa Doe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">3天以前</span>
											</div>

											<div>
												<span class="label label-success label-sm arrowed-in">approved</span>
											</div>
										</div>
									</div>
								</div>

								<div class="center">
									<i class="icon-group icon-2x green"></i>

									&nbsp;
									<a href="#">
										查看所有会员 &nbsp;
										<i class="icon-arrow-right"></i>
									</a>
								</div>

								<div class="hr hr-double hr8"></div>
							</div><!-- member-tab -->

							<div class="tab-pane" id="comment-tab">
								<div class="comments">
									<div class="itemdiv commentdiv">
										<div class="user">
											<img alt="Bob Doe's Avatar" src="static/avatars/avatar.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Bob Doe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="green">6 min</span>
											</div>

											<div class="text">
												<i class="icon-quote-left"></i>
												Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque commodo massa sed ipsum porttitor facilisis …
											</div>
										</div>

										<div class="tools">
											<div class="inline position-relative">
												<button class="btn btn-minier bigger btn-yellow dropdown-toggle" data-toggle="dropdown">
													<i class="icon-angle-down icon-only bigger-120"></i>
												</button>

												<ul class="dropdown-menu dropdown-only-icon dropdown-yellow pull-right dropdown-caret dropdown-close">
													<li>
														<a title="Approve" class="tooltip-success" href="#" data-rel="tooltip">
															<span class="green">
																<i class="icon-ok bigger-110"></i>
															</span>
														</a>
													</li>

													<li>
														<a title="Reject" class="tooltip-warning" href="#" data-rel="tooltip">
															<span class="orange">
																<i class="icon-remove bigger-110"></i>
															</span>
														</a>
													</li>

													<li>
														<a title="Delete" class="tooltip-error" href="#" data-rel="tooltip">
															<span class="red">
																<i class="icon-trash bigger-110"></i>
															</span>
														</a>
													</li>
												</ul>
											</div>
										</div>
									</div>

									<div class="itemdiv commentdiv">
										<div class="user">
											<img alt="Jennifer's Avatar" src="static/avatars/avatar1.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Jennifer</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="blue">15 min</span>
											</div>

											<div class="text">
												<i class="icon-quote-left"></i>
												Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque commodo massa sed ipsum porttitor facilisis …
											</div>
										</div>

										<div class="tools">
											<div class="action-buttons bigger-125">
												<a href="#">
													<i class="icon-pencil blue"></i>
												</a>

												<a href="#">
													<i class="icon-trash red"></i>
												</a>
											</div>
										</div>
									</div>

									<div class="itemdiv commentdiv">
										<div class="user">
											<img alt="Joe's Avatar" src="static/avatars/avatar2.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Joe</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="orange">22 min</span>
											</div>

											<div class="text">
												<i class="icon-quote-left"></i>
												Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque commodo massa sed ipsum porttitor facilisis …
											</div>
										</div>

										<div class="tools">
											<div class="action-buttons bigger-125">
												<a href="#">
													<i class="icon-pencil blue"></i>
												</a>

												<a href="#">
													<i class="icon-trash red"></i>
												</a>
											</div>
										</div>
									</div>

									<div class="itemdiv commentdiv">
										<div class="user">
											<img alt="Rita's Avatar" src="static/avatars/avatar3.png">
										</div>

										<div class="body">
											<div class="name">
												<a href="#">Rita</a>
											</div>

											<div class="time">
												<i class="icon-time"></i>
												<span class="red">50 min</span>
											</div>

											<div class="text">
												<i class="icon-quote-left"></i>
												Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque commodo massa sed ipsum porttitor facilisis …
											</div>
										</div>

										<div class="tools">
											<div class="action-buttons bigger-125">
												<a href="#">
													<i class="icon-pencil blue"></i>
												</a>

												<a href="#">
													<i class="icon-trash red"></i>
												</a>
											</div>
										</div>
									</div>
								</div>

								<div class="hr hr8"></div>

								<div class="center">
									<i class="icon-comments-alt icon-2x green"></i>

									&nbsp;
									<a href="#">
										See all comments &nbsp;
										<i class="icon-arrow-right"></i>
									</a>
								</div>

								<div class="hr hr-double hr8"></div>
							</div>
						</div>
					</div><!-- /widget-main -->
				</div><!-- /widget-body -->
			</div><!-- /widget-box -->
		</div><!-- /span -->

		<div class="col-sm-6">
			<div class="widget-box ">
				<div class="widget-header">
					<h4 class="lighter smaller">
						<i class="icon-comment blue"></i>
						会话
					</h4>
				</div>

				<div class="widget-body">
					<div class="widget-main no-padding">
						<div class="dialogs">
							<div class="itemdiv dialogdiv">
								<div class="user">
									<img alt="Alexa's Avatar" src="static/avatars/avatar1.png">
								</div>

								<div class="body">
									<div class="time">
										<i class="icon-time"></i>
										<span class="green">4秒钟前</span>
									</div>

									<div class="name">
										<a href="#">Alexa</a>
									</div>
									<div class="text">大家好啊</div>

									<div class="tools">
										<a class="btn btn-minier btn-info" href="#">
											<i class="icon-only icon-share-alt"></i>
										</a>
									</div>
								</div>
							</div>

							<div class="itemdiv dialogdiv">
								<div class="user">
									<img alt="John's Avatar" src="static/avatars/avatar.png">
								</div>

								<div class="body">
									<div class="time">
										<i class="icon-time"></i>
										<span class="blue">38秒以前</span>
									</div>

									<div class="name">
										<a href="#">John</a>
									</div>
									<div class="text">框架很好用嘛</div>

									<div class="tools">
										<a class="btn btn-minier btn-info" href="#">
											<i class="icon-only icon-share-alt"></i>
										</a>
									</div>
								</div>
							</div>

							<div class="itemdiv dialogdiv">
								<div class="user">
									<img alt="Bob's Avatar" src="static/avatars/user.jpg">
								</div>

								<div class="body">
									<div class="time">
										<i class="icon-time"></i>
										<span class="orange">2分钟以前</span>
									</div>

									<div class="name">
										<a href="#">Bob</a>
										<span class="label label-info arrowed arrowed-in-right">admin</span>
									</div>
									<div class="text">欢迎大家使用ACE后台管理系统.</div>

									<div class="tools">
										<a class="btn btn-minier btn-info" href="#">
											<i class="icon-only icon-share-alt"></i>
										</a>
									</div>
								</div>
							</div>

							<div class="itemdiv dialogdiv">
								<div class="user">
									<img alt="Jim's Avatar" src="static/avatars/avatar4.png">
								</div>

								<div class="body">
									<div class="time">
										<i class="icon-time"></i>
										<span class="grey">3分钟以前</span>
									</div>

									<div class="name">
										<a href="#">Jim</a>
									</div>
									<div class="text">大家多提提BUG</div>

									<div class="tools">
										<a class="btn btn-minier btn-info" href="#">
											<i class="icon-only icon-share-alt"></i>
										</a>
									</div>
								</div>
							</div>

							<div class="itemdiv dialogdiv">
								<div class="user">
									<img alt="Alexa's Avatar" src="static/avatars/avatar1.png">
								</div>

								<div class="body">
									<div class="time">
										<i class="icon-time"></i>
										<span class="green">4分钟以前</span>
									</div>

									<div class="name">
										<a href="#">Alexa</a>
									</div>
									<div class="text">继续支持ACE后台系统</div>

									<div class="tools">
										<a class="btn btn-minier btn-info" href="#">
											<i class="icon-only icon-share-alt"></i>
										</a>
									</div>
								</div>
							</div>
						</div>

						<form>
							<div class="form-actions">
								<div class="input-group">
									<input name="message" class="form-control" type="text" placeholder="Type your message here ...">
									<span class="input-group-btn">
										<button class="btn btn-sm btn-info no-radius" type="button">
											<i class="icon-share-alt"></i>
											发送
										</button>
									</span>
								</div>
							</div>
						</form>
					</div><!-- /widget-main -->
				</div><!-- /widget-body -->
			</div><!-- /widget-box -->
		</div><!-- /span -->
	</div><!-- /row -->

	<!-- PAGE CONTENT ENDS -->
</div><!-- /.col -->
</div><!-- /.row -->
</div><!-- /.page-content -->
</div>
</template>
<script>
export default {
name: 'imain',
data () {
return {
message: ''
}    
}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
#navbar,#sidebar{
		display:block;
	}
</style>