<template>
    <div id="foot">
        
    </div>
</template>

